<p>Dear User,</p>
<p>Reminder: Your event <b>{{ $event->title }}</b> is scheduled for {{ $event->event_date }}</p>
<p>Message: {{$event->message}}</p>
<p>Thank you!</p>