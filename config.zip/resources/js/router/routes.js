import Calendar from '../components/Calendar.vue';

export const routes = [

    //============================Temp user============================================================================================
    { name: '/',                       path: '/',                      component: Calendar },
   

];